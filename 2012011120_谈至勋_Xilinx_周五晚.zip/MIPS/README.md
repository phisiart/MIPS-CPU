MIPS
===

This is a MIPS program to find the greatest common divisor using the CPU we designed. It will get two number from the UART, find the greatest common divisor and send it through UART.
