CPU
===

This is the summer 2014 project of MIPS CPU implementation.

In the "30230852 Digital Logic and Processors" course, students work in groups to write `Verilog` code to implement a simple CPU based on the MIPS architecture.
