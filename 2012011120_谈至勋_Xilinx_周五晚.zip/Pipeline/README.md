Pipeline
===

This is the CPU implemented with pipeline.
