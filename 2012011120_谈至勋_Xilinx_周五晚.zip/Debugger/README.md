# Instruction Printer

    iverilog rom.v TestInstPrint.v InstPrint.v 
    vvp a.out